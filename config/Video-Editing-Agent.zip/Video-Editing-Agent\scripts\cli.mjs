#!/usr/bin/env node
// Convenience dispatcher: `node scripts/cli.mjs <command> [args]`.
// Most workflows call the step scripts directly; this is a friendly front door.
import { spawn } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { listProjects, loadProject } from '../lib/project.mjs';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const MAP = {
  doctor: 'doctor', setup: 'setup', intake: 'intake', transcribe: 'transcribe',
  'rough-cut': 'rough-cut', rough: 'rough-cut', graphics: 'build-composition',
  render: 'render', captions: 'captions', music: 'music',
  export: 'finalize', finalize: 'finalize', thumbnail: 'thumbnail', thumb: 'thumbnail',
  prune: 'prune',
};

const [, , cmd, ...rest] = process.argv;

if (!cmd || cmd === 'help' || cmd === '--help') {
  console.log(`Video Editing Agent
Usage: node scripts/cli.mjs <command> [options]

Pipeline:
  intake <file>       copy raw clip into a new project
  rough-cut           transcribe + auto-cut silence/filler, render preview
  graphics            plan + render motion graphics
  render              re-render (incremental) after editing plan/timeline
  captions            burn word-timed captions (short-form)
  music --music <f>   add ducked background music
  export              promote to outputs/<job>.final.mp4 (+ Downloads)
  thumbnail           generate a thumbnail

Utilities:
  doctor              check the toolchain
  setup               install/verify dependencies
  prune               reclaim disk from a project
  list                list projects
  status [job]        show a project's step progress

Most commands take --job <name> (defaults to the newest project).`);
  process.exit(0);
}

if (cmd === 'list') {
  const all = listProjects();
  if (!all.length) { console.log('No projects yet. Run: node scripts/cli.mjs intake <file>'); process.exit(0); }
  for (const pr of all) {
    const done = Object.entries(pr.steps || {}).filter(([, v]) => v).map(([k]) => k).join(', ');
    console.log(`  ${pr.job.padEnd(28)} ${pr.format.padEnd(20)} [${done || 'intake'}]`);
  }
  process.exit(0);
}

if (cmd === 'status') {
  const job = rest[0] || (listProjects()[0]?.job);
  if (!job) { console.log('No projects.'); process.exit(0); }
  const pr = loadProject(job);
  if (!pr) { console.log(`No project "${job}".`); process.exit(1); }
  console.log(`\n${job}  (${pr.format})`);
  const order = ['intake', 'roughCut', 'graphics', 'captions', 'music', 'export'];
  for (const s of order) console.log(`  ${pr.steps?.[s] ? '✓' : '·'}  ${s}`);
  console.log('');
  process.exit(0);
}

const script = MAP[cmd];
if (!script) { console.error(`Unknown command "${cmd}". Try: node scripts/cli.mjs help`); process.exit(1); }

const node = process.execPath;
const child = spawn(node, [path.join(HERE, `${script}.mjs`), ...rest], { stdio: 'inherit' });
child.on('close', (code) => process.exit(code ?? 0));
