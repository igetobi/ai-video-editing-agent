#!/usr/bin/env node
// Thumbnail generator. Grabs a frame and (optionally) overlays a bold title with
// an accent bar. Long-form format sets thumb: always; shorts usually skip.
//
// Usage:
//   node scripts/thumbnail.mjs [--job name] [--time 3.5] [--title "Big Idea"]
import fs from 'node:fs';
import path from 'node:path';
import { parseArgs } from '../lib/args.mjs';
import { loadConfig, resolveTool, DIRS, ensureDir } from '../lib/paths.mjs';
import { stream } from '../lib/exec.mjs';
import { loadFormat, resolveStyleFor } from '../lib/presets.mjs';
import { resolveJob, projectPaths, loadTimeline, sourceFile, latestVideo } from '../lib/project.mjs';

function findFont() {
  const local = path.join(DIRS.assets, 'fonts');
  if (fs.existsSync(local)) {
    const f = fs.readdirSync(local).find((x) => /\.(ttf|otf)$/i.test(x));
    if (f) return path.join(local, f);
  }
  for (const c of ['C:/Windows/Fonts/arialbd.ttf', 'C:/Windows/Fonts/ARIALBD.TTF', '/System/Library/Fonts/Supplemental/Arial Bold.ttf']) {
    if (fs.existsSync(c)) return c;
  }
  return null;
}

async function main() {
  const { flags } = parseArgs();
  const cfg = loadConfig();
  const job = resolveJob(flags.job);
  const p = projectPaths(job);
  const timeline = loadTimeline(job);
  const format = timeline ? loadFormat(timeline.format) : null;
  const { style } = format ? resolveStyleFor(format, timeline.style) : { style: {} };
  const W = timeline?.dims?.width || 1920, H = timeline?.dims?.height || 1080;

  const input = latestVideo(job) || sourceFile(job);
  const t = flags.time != null ? Number(flags.time) : Math.min(3, (timeline?.stats?.cutDuration || 10) * 0.1);
  const accent = (style.colors?.accent || '#D97757').replace('#', '0x');

  ensureDir(p.work);
  const ffmpeg = resolveTool('ffmpeg', cfg);
  const title = flags.title;
  const font = title ? findFont() : null;

  // Copy font into the ffmpeg cwd (outputs/) to dodge Windows drawtext path escaping.
  ensureDir(DIRS.outputs);
  let vf = `scale=${W}:${H}:force_original_aspect_ratio=increase,crop=${W}:${H}`;
  if (title && font) {
    fs.copyFileSync(font, path.join(DIRS.outputs, 'thumbfont.ttf'));
    const fs2 = Math.round(H * 0.11);
    const safe = title.replace(/:/g, '\\:').replace(/'/g, "’");
    vf += `,drawbox=x=0:y=ih-${Math.round(H * 0.28)}:w=iw:h=${Math.round(H * 0.28)}:color=black@0.55:t=fill`;
    vf += `,drawtext=fontfile=thumbfont.ttf:text='${safe}':fontcolor=white:fontsize=${fs2}:x=(w-text_w)/2:y=h-${Math.round(H * 0.20)}`;
    vf += `,drawbox=x=(iw-${Math.round(W * 0.12)})/2:y=ih-${Math.round(H * 0.06)}:w=${Math.round(W * 0.12)}:h=${Math.round(H * 0.012)}:color=${accent}:t=fill`;
  } else if (title && !font) {
    console.warn('No usable font found for the title — rendering a plain frame. Drop a .ttf in assets/fonts.');
  }

  const out = path.join(DIRS.outputs, `${job}.thumb.png`);
  const code = await stream(ffmpeg, [
    '-hide_banner', '-loglevel', 'warning', '-y',
    '-ss', String(t), '-i', path.resolve(input),
    '-frames:v', '1', '-update', '1', '-vf', vf,
    path.basename(out),
  ], { cwd: DIRS.outputs });
  fs.rmSync(path.join(DIRS.outputs, 'thumbfont.ttf'), { force: true });
  if (code !== 0) { console.error('Thumbnail render failed.'); process.exit(1); }

  console.log(`\n✓ Thumbnail → outputs/${job}.thumb.png  (${W}x${H}, frame @ ${t.toFixed(1)}s)\n`);
}

main().catch((e) => { console.error('\nThumbnail failed:', e.message); process.exit(1); });
