# Start Here — Claude Video Editing Agent

You've been handed a local, agent-driven video editor: drop in raw footage and it produces a tight, smooth, graphics-rich, captioned cut. Deterministic Node scripts do the mechanical work (cutting, audio, rendering); an AI agent supplies the judgment (which takes to keep, what the graphics say).

## 1. Prerequisites (install once)
- **Node.js ≥ 22** — https://nodejs.org
- **uv** (Python manager, for WhisperX) — https://docs.astral.sh/uv/
- **Windows:** `winget` (built in). **macOS/Linux:** install `ffmpeg` yourself (`brew install ffmpeg` / apt).

## 2. Set up (one time, ~10–20 min — mostly downloads)
```bash
npm run setup            # installs ffmpeg, WhisperX (engine/whisperx), HyperFrames
node scripts/doctor.mjs  # should print all green
```

## 3. Make your first edit
Open this folder with your coding agent (Claude Code recommended) and say:
> "Here's my raw clip: `<path>`. Do the rough cut."

…then "add graphics", "add captions", "add music", "export". Or run it by hand:
```bash
node scripts/intake.mjs "C:/path/to/raw.mp4"
node scripts/rough-cut.mjs
node scripts/build-composition.mjs
node scripts/finalize.mjs
```

## 4. Learn the system
- **README.md** — full usage, the 3 formats, customization, troubleshooting
- **CLAUDE.md** — the 7-step pipeline the agent follows + golden rules
- **.claude/skills/** — one skill per step (how-to + when to ask you)

## Works with any model / agent
The engine is just scripts + ffmpeg + WhisperX + HyperFrames, so it's **model-agnostic**. Claude Code is best-supported (skills auto-load when you name a step), but any coding agent that reads files and runs shell commands (Cursor, Codex, Gemini CLI, Cline, …) can drive it, and every step also runs manually from the CLI. A stronger model just gives better creative judgment — not a different pipeline.

## Good to know
- **Cutting bad takes:** each project gets a re-runnable `projects/<job>/excludes.json` cut-list — list the words/phrases to drop, re-run `rough-cut`, done. Reversible.
- **Smooth cuts:** every seam is auto cross-dissolved (audio + video). Tune in `config.json` → `render.transitionSec`.
- **CPU note:** with no NVIDIA GPU, WhisperX transcription of long clips is slow — test on a short slice first.
- **Your assets:** drop logos/PNGs in `assets/`, and `Coolvetica.ttf` in `assets/fonts/` to match the reference caption font (else it falls back to Arial Black).
- Everything is **local** — nothing is uploaded or posted.
