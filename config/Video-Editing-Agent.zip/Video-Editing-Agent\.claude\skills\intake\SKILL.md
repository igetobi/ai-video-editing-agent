---
name: intake
description: Step 1 of the video pipeline. Start a new editing project from a raw clip — copy it in, detect the format (long-form 16:9, short-explainer 9:16, tiktok-raw 9:16), and scaffold the project. Use when the user drops raw footage or says "start a new project / new video / here's the raw clip".
---

# Intake — start a project from raw footage

This is step 1 of the 7-step pipeline (see `CLAUDE.md`). It copies the raw clip into `projects/<job>/raw/`, probes it, auto-detects the format from aspect ratio, and writes `project.json` + an empty `timeline.json`.

## Do this

1. Get the raw file path from the user (they usually paste it). On Windows, copy a file's path in Explorer with `Shift+Right-click → Copy as path`.
2. Run:

```bash
node scripts/intake.mjs "<RAW_VIDEO_PATH>"
```

3. Optional flags:
   - `--format long-form-youtube | short-explainer | tiktok-raw` — force the format instead of auto-detecting.
   - `--job my-name` — set the project name (defaults to a slug of the filename).

## After it runs

- Report the detected format and duration back to the user.
- If the auto-detected format looks wrong for their intent (e.g. a 9:16 clip they want as `tiktok-raw` not `short-explainer`), re-run with `--format`.
- Then move to the **rough-cut** skill.

Do not edit the raw file. Everything downstream reads from the project copy.
