#!/usr/bin/env node
// Housekeeping — reclaim disk from a project's intermediates.
//   (default)    delete regenerable composition/ scratch, keep the segment cache
//   --deep       also delete segments/ + work/ (next edit re-renders from source)
//   --dry-run    show what would be freed, delete nothing
//
// Usage: node scripts/prune.mjs [--job name] [--deep] [--dry-run]
import fs from 'node:fs';
import path from 'node:path';
import { parseArgs, bool } from '../lib/args.mjs';
import { resolveJob, projectPaths } from '../lib/project.mjs';

function dirSize(p) {
  if (!fs.existsSync(p)) return 0;
  let total = 0;
  for (const e of fs.readdirSync(p, { withFileTypes: true })) {
    const full = path.join(p, e.name);
    if (e.isDirectory()) total += dirSize(full);
    else total += fs.statSync(full).size;
  }
  return total;
}
const mb = (n) => (n / 1048576).toFixed(1) + ' MB';

function main() {
  const { flags } = parseArgs();
  const job = resolveJob(flags.job);
  const p = projectPaths(job);
  const dry = bool(flags['dry-run']);
  const deep = bool(flags.deep);

  const targets = [p.composition];
  if (deep) targets.push(p.segments, p.work);

  let freed = 0;
  for (const t of targets) {
    const size = dirSize(t);
    if (!fs.existsSync(t)) continue;
    freed += size;
    console.log(`${dry ? '[dry] would remove' : 'removing'}  ${path.relative(process.cwd(), t)}  (${mb(size)})`);
    if (!dry) fs.rmSync(t, { recursive: true, force: true });
  }
  console.log(`\n${dry ? 'Would free' : 'Freed'} ~${mb(freed)} for job "${job}".`);
  if (!deep) console.log('Segment cache kept — re-renders stay fast. Use --deep to clear it too.\n');
}

main();
