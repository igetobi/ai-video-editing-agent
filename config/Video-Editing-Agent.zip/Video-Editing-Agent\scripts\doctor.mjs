#!/usr/bin/env node
// Toolchain self-check. Run any time: `npm run doctor` or `node scripts/doctor.mjs`.
// Verifies Node, ffmpeg/ffprobe, the WhisperX venv, and the HyperFrames CLI.
import fs from 'node:fs';
import { capture } from '../lib/exec.mjs';
import { resolveTool, pythonPath, hyperframesEntry, loadConfig, IS_WIN } from '../lib/paths.mjs';
import { whisperxBin } from '../lib/whisperx.mjs';

const cfg = loadConfig();
const rows = [];
let hardFail = false;

function ok(name, detail) { rows.push({ status: 'ok', name, detail }); }
function warn(name, detail) { rows.push({ status: 'warn', name, detail }); }
function fail(name, detail) { rows.push({ status: 'fail', name, detail }); hardFail = true; }

// Node
{
  const major = Number(process.versions.node.split('.')[0]);
  if (major >= 22) ok('Node.js', `v${process.versions.node}`);
  else fail('Node.js', `v${process.versions.node} — HyperFrames needs Node >= 22`);
}

// ffmpeg / ffprobe
for (const tool of ['ffmpeg', 'ffprobe']) {
  const p = resolveTool(tool, cfg);
  if (p) {
    const v = capture(p, ['-version']);
    const line = (v.stdout.split(/\r?\n/)[0] || '').trim();
    ok(tool, line || p);
  } else {
    fail(tool, IS_WIN ? 'missing — `winget install Gyan.FFmpeg`' : 'missing — install ffmpeg');
  }
}

// Python venv
{
  const py = pythonPath(cfg);
  if (py) {
    const v = capture(py, ['--version']);
    ok('python (venv)', (v.stdout || v.stderr).trim() || py);
  } else {
    fail('python (venv)', 'missing — run `node scripts/setup.mjs`');
  }
}

// WhisperX (existence only; importing torch to get --version is slow)
{
  const w = whisperxBin();
  if (w) ok('whisperx', w);
  else fail('whisperx', 'missing — run `node scripts/setup.mjs`');
}

// HyperFrames CLI
{
  const hf = hyperframesEntry();
  if (hf) {
    const v = capture(process.execPath, [hf, '--version']);
    const line = (v.stdout || '').trim().split(/\r?\n/)[0];
    ok('hyperframes', line || hf);
  } else {
    fail('hyperframes', 'missing — run `npm install`');
  }
}

// HyperFrames render project
{
  const idx = 'engine/hyperframes/index.html';
  if (fs.existsSync(idx)) ok('hyperframes project', 'engine/hyperframes');
  else warn('hyperframes project', 'not scaffolded — `npm run setup` will create engine/hyperframes');
}

// Presets present
{
  const need = ['presets/formats/short-explainer.json', 'presets/formats/tiktok-raw.json', 'presets/formats/long-form-youtube.json'];
  const missing = need.filter((f) => !fs.existsSync(f));
  if (!missing.length) ok('presets', '3 formats + styles');
  else warn('presets', `missing: ${missing.join(', ')}`);
}

// Report
const icon = { ok: '✓', warn: '!', fail: '✗' };
const pad = Math.max(...rows.map((r) => r.name.length));
console.log('\nVideo Editing Agent — doctor\n' + '-'.repeat(34));
for (const r of rows) {
  console.log(`  ${icon[r.status]}  ${r.name.padEnd(pad)}  ${r.detail || ''}`);
}
console.log('-'.repeat(34));
if (hardFail) {
  console.log('Some required tools are missing. Run: npm run setup\n');
  process.exit(1);
} else {
  console.log('All required tools present. You are ready to edit.\n');
}
