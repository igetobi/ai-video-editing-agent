#!/usr/bin/env node
// Transcribe a project's source with WhisperX (word-level). Standalone, and also
// imported by rough-cut.mjs so "do the rough cut" transcribes automatically.
//
// Usage: node scripts/transcribe.mjs [--job name] [--force]
import fs from 'node:fs';
import path from 'node:path';
import { parseArgs, bool } from '../lib/args.mjs';
import { loadConfig } from '../lib/paths.mjs';
import { transcribe, normalizeTranscript } from '../lib/whisperx.mjs';
import {
  resolveJob, projectPaths, sourceFile, saveTranscript, loadTranscript,
} from '../lib/project.mjs';

export async function ensureTranscript(job, cfg = loadConfig(), { force = false } = {}) {
  const p = projectPaths(job);
  if (!force && fs.existsSync(p.transcript)) {
    return loadTranscript(job);
  }
  const src = sourceFile(job);
  const outDir = path.join(p.work, 'transcribe');
  console.log(`Transcribing (WhisperX, model=${cfg.whisper?.model})... this runs on CPU here, so be patient.`);
  const jsonPath = await transcribe(src, outDir, cfg);
  const raw = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
  const norm = normalizeTranscript(raw);
  saveTranscript(job, norm);
  console.log(`✓ Transcript: ${norm.words.length} words, ${norm.segments.length} segments → projects/${job}/transcript.json`);
  return norm;
}

// Run directly
if (import.meta.url === `file://${process.argv[1].replace(/\\/g, '/')}` || process.argv[1]?.endsWith('transcribe.mjs')) {
  const { flags } = parseArgs();
  const cfg = loadConfig();
  const job = resolveJob(flags.job);
  ensureTranscript(job, cfg, { force: bool(flags.force) })
    .catch((e) => { console.error('Transcription failed:', e.message); process.exit(1); });
}
