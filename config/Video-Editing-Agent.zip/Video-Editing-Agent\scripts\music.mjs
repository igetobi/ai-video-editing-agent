#!/usr/bin/env node
// Step 6 — Background music (optional). Mixes a track under the voice with
// sidechain ducking, then re-normalizes loudness.
//
// Usage:
//   node scripts/music.mjs --music "C:/path/to/track.mp3" [--job name]
//        [--level -23]   target loudness (LUFS) for the ducked music bed
import fs from 'node:fs';
import path from 'node:path';
import { parseArgs } from '../lib/args.mjs';
import { loadConfig } from '../lib/paths.mjs';
import { mixMusic } from '../lib/ffmpeg.mjs';
import { resolveJob, projectPaths, loadProject, saveProject, latestVideo } from '../lib/project.mjs';

async function main() {
  const { _, flags } = parseArgs();
  const cfg = loadConfig();
  const job = resolveJob(flags.job);
  const p = projectPaths(job);

  const music = flags.music || _[0];
  if (!music) { console.error('Provide a music file: node scripts/music.mjs --music <path>'); process.exit(1); }
  const musicPath = path.resolve(music);
  if (!fs.existsSync(musicPath)) { console.error(`Music file not found: ${musicPath}`); process.exit(1); }

  const input = latestVideo(job);
  if (!input) { console.error('No video yet — run rough cut / graphics first.'); process.exit(1); }
  if (input.endsWith('music-mixed.mp4')) {
    console.log('Re-mixing over the pre-music video (using graphics/captions output).');
  }
  // Never mix on top of an already-mixed file — start from the pre-music stage.
  const base = [path.join(p.work, 'captioned.mp4'), p.composited, p.preview].find((f) => fs.existsSync(f));

  const musicLUFS = flags.level != null ? Number(flags.level) : (cfg.audio?.musicUnderVoiceLUFS ?? -23);
  const out = path.join(p.work, 'music-mixed.mp4');
  console.log(`Mixing music under voice (bed target ${musicLUFS} LUFS, sidechain duck)...`);
  await mixMusic(base, musicPath, out, { musicLUFS }, cfg);

  const project = loadProject(job);
  project.steps.music = true;
  project.music = { path: musicPath, levelLUFS: musicLUFS };
  saveProject(job, project);

  console.log(`\n✓ Music added → projects/${job}/work/music-mixed.mp4`);
  console.log(`  If it's too loud/quiet, re-run with a different --level (e.g. --level -26).`);
  console.log(`\nNext: export →  node scripts/finalize.mjs --job ${job}\n`);
}

main().catch((e) => { console.error('\nMusic step failed:', e.message); process.exit(1); });
