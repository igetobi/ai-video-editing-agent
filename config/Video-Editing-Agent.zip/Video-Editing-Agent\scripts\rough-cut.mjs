#!/usr/bin/env node
// Step 2 — Rough cut. Turn a word-level transcript into a tight timeline.json,
// then render a preview. Cuts long silences AND filler words; because a span
// breaks at every removed word, filler audio is never left in the seam. Padding
// is clamped to the gap midpoint so adjacent cuts never overlap or re-add filler.
//
// Usage:
//   node scripts/rough-cut.mjs [--job name] [--force-transcribe]
//        [--aggressive]        also remove hedge words (like, you know, ...)
//        [--no-preview]        compute timeline only, skip rendering
import fs from 'node:fs';
import path from 'node:path';
import { parseArgs, bool } from '../lib/args.mjs';
import { loadConfig } from '../lib/paths.mjs';
import { trimConcat, trimConcatSmooth } from '../lib/ffmpeg.mjs';
import { loadFormat } from '../lib/presets.mjs';
import {
  resolveJob, projectPaths, sourceFile, loadProject, saveProject,
  saveTimeline, loadTimeline, nextSegmentId,
} from '../lib/project.mjs';
import { ensureTranscript } from './transcribe.mjs';

const norm = (w) => String(w).toLowerCase().replace(/^[^\p{L}\p{N}']+|[^\p{L}\p{N}']+$/gu, '');

function markFillers(words, cfg, aggressive) {
  const rc = cfg.roughCut || {};
  const single = new Set((rc.removeFillers ? rc.fillerWords || [] : []).map(norm));
  const phrases = (aggressive || rc.removeAggressiveFillers)
    ? (rc.aggressiveFillers || []).map((p) => p.split(/\s+/).map(norm))
    : [];
  const flat = words.map((w) => ({ ...w, keep: true, n: norm(w.word) }));
  // single-word fillers
  for (const w of flat) if (single.has(w.n)) w.keep = false;
  // multi-word phrases (only if all words currently kept and contiguous)
  for (const phrase of phrases) {
    for (let i = 0; i + phrase.length <= flat.length; i++) {
      let match = true;
      for (let j = 0; j < phrase.length; j++) if (flat[i + j].n !== phrase[j]) { match = false; break; }
      if (match) for (let j = 0; j < phrase.length; j++) flat[i + j].keep = false;
    }
  }
  return flat;
}

// Tokenize like the transcript: split on whitespace, strip each token to alnum.
const mtok = (s) => String(s).split(/\s+/).map((t) => t.toLowerCase().replace(/[^a-z0-9]/g, '')).filter(Boolean);

function loadExcludes(job) {
  const p = path.join(projectPaths(job).root, 'excludes.json');
  if (!fs.existsSync(p)) return [];
  const data = JSON.parse(fs.readFileSync(p, 'utf8'));
  return Array.isArray(data) ? data : (data.excludes || data.cuts || []);
}

/**
 * Apply a manual cut-list to the word array (marks matched words keep=false).
 * Entry forms:
 *   "phrase" | { phrase }            exact contiguous word run (first occurrence)
 *   { from, to }                     from start of `from` to end of the next `to`
 *   { start, end }                   explicit source-time range (seconds)
 */
function applyExcludes(words, excludes) {
  const toks = words.map((w) => w.word.toLowerCase().replace(/[^a-z0-9]/g, ''));
  const findSeq = (from, seq) => {
    if (!seq.length) return -1;
    for (let i = from; i + seq.length <= toks.length; i++) {
      let ok = true;
      for (let k = 0; k < seq.length; k++) if (toks[i + k] !== seq[k]) { ok = false; break; }
      if (ok) return i;
    }
    return -1;
  };
  const results = [];
  for (const ex of excludes) {
    let a = -1, b = -1, label = '';
    if (typeof ex === 'string' || ex.phrase) {
      const seq = mtok(ex.phrase || ex);
      const i = findSeq(0, seq);
      if (i >= 0) { a = i; b = i + seq.length; }
      label = ex.phrase || ex;
    } else if (ex.from && ex.to) {
      const i = findSeq(0, mtok(ex.from));
      if (i >= 0) { const st = mtok(ex.to); const j = findSeq(i, st); if (j >= 0) { a = i; b = j + st.length; } }
      label = `${ex.from} … ${ex.to}`;
    } else if (typeof ex.start === 'number' && typeof ex.end === 'number') {
      words.forEach((w, i) => { const m = (w.start + w.end) / 2; if (m >= ex.start && m <= ex.end) { if (a < 0) a = i; b = i + 1; } });
      label = `${ex.start}-${ex.end}s`;
    }
    if (a >= 0 && b > a) { for (let i = a; i < b; i++) words[i].keep = false; results.push({ label, matched: true, removed: b - a }); }
    else results.push({ label, matched: false, removed: 0 });
  }
  return results;
}

async function renderPreview(job, spans, fps, cfg) {
  const p = projectPaths(job);
  const smooth = cfg.render?.smoothCuts !== false && spans.length > 1;
  const opts = { fps, transitionSec: cfg.render?.transitionSec };
  if (smooth) await trimConcatSmooth(sourceFile(job), spans, p.preview, opts, cfg);
  else await trimConcat(sourceFile(job), spans, p.preview, opts, cfg);
  return p.preview;
}

function buildSpans(words, cfg, duration) {
  const rc = cfg.roughCut || {};
  const silence = rc.silenceThresholdSec ?? 0.6;
  const pad = rc.keepPaddingSec ?? 0.12;
  const minSeg = rc.minSegmentSec ?? 0.25;

  // 1. Contiguous runs of kept words; break at any removed word or big silence.
  let spans = [];
  let cur = null;
  for (const w of words) {
    if (!w.keep || typeof w.start !== 'number' || typeof w.end !== 'number') { if (cur) { spans.push(cur); cur = null; } continue; }
    if (!cur) { cur = { in: w.start, out: w.end, words: [w] }; continue; }
    if (w.start - cur.out > silence) { spans.push(cur); cur = { in: w.start, out: w.end, words: [w] }; }
    else { cur.out = w.end; cur.words.push(w); }
  }
  if (cur) spans.push(cur);

  // 2. Clamped padding — never cross the midpoint to a neighbor.
  spans = spans.map((s, i) => {
    const prev = spans[i - 1], next = spans[i + 1];
    let inS = Math.max(0, s.in - pad);
    let outS = Math.min(duration || s.out + pad, s.out + pad);
    if (prev) inS = Math.max(inS, (prev.out + s.in) / 2);
    if (next) outS = Math.min(outS, (s.out + next.in) / 2);
    return { ...s, in: inS, out: outS };
  });

  // 3. Merge near-touching spans, drop tiny ones.
  const merged = [];
  for (const s of spans) {
    const last = merged[merged.length - 1];
    if (last && s.in - last.out < 0.04) { last.out = s.out; last.words.push(...s.words); }
    else merged.push({ ...s });
  }
  return merged.filter((s) => s.out - s.in >= minSeg);
}

async function main() {
  const { flags } = parseArgs();
  const cfg = loadConfig();
  const job = resolveJob(flags.job);
  const project = loadProject(job);
  const format = loadFormat(project.format);
  const canvas = format.canvas || { width: 1920, height: 1080, fps: 30 };

  // Re-render the preview from a hand-edited timeline WITHOUT recomputing cuts
  // (so manual sourceIn/sourceOut/segment edits are preserved).
  if (bool(flags['from-timeline'])) {
    const tl = loadTimeline(job);
    if (!tl?.segments?.length) { console.error('No timeline to preview.'); process.exit(1); }
    console.log('Re-rendering preview from current timeline.json...');
    await renderPreview(job, tl.segments.map((s) => ({ in: s.sourceIn, out: s.sourceOut })), tl.fps, cfg);
    console.log(`✓ preview: projects/${job}/preview.mp4\n`);
    return;
  }

  const transcript = await ensureTranscript(job, cfg, { force: bool(flags['force-transcribe']) });
  if (!transcript.words.length) {
    console.error('No word timestamps found in the transcript. Cannot compute cuts.');
    process.exit(1);
  }

  const duration = project.media?.duration || 0;
  const marked = markFillers(transcript.words, cfg, bool(flags.aggressive));

  // Manual cut-list (bad takes / restarts) from projects/<job>/excludes.json.
  const excludes = loadExcludes(job);
  if (excludes.length) {
    const res = applyExcludes(marked, excludes);
    const ok = res.filter((r) => r.matched).length;
    console.log(`\nManual cuts (excludes.json): ${ok}/${res.length} matched`);
    for (const r of res) console.log(`   ${r.matched ? '✓' : '✗ NOT FOUND'} ${r.label}${r.matched ? `  (${r.removed} words)` : ''}`);
  }

  const spans = buildSpans(marked, cfg, duration);
  if (!spans.length) { console.error('Rough cut produced 0 segments — check thresholds in config.json.'); process.exit(1); }

  const segments = spans.map((s, i) => ({
    id: nextSegmentId(i),
    index: i,
    sourceIn: Number(s.in.toFixed(3)),
    sourceOut: Number(s.out.toFixed(3)),
    duration: Number((s.out - s.in).toFixed(3)),
    text: s.words.map((w) => w.word).join(' ').replace(/\s+([,.!?])/g, '$1').trim(),
    words: s.words.map((w) => ({ word: w.word, start: Number(w.start.toFixed(3)), end: Number(w.end.toFixed(3)) })),
    graphic: null,
    captions: null,
    keep: true,
  }));

  const keptDur = segments.reduce((a, s) => a + s.duration, 0);
  const timeline = {
    job, format: project.format, style: project.style || format.style || null,
    source: project.source,
    fps: canvas.fps || cfg.render?.fps || 30,
    dims: { width: canvas.width, height: canvas.height },
    sourceDims: { width: project.media?.width, height: project.media?.height },
    segments,
    stats: { sourceDuration: duration, cutDuration: Number(keptDur.toFixed(2)), segmentCount: segments.length },
  };
  saveTimeline(job, timeline);

  // Human-readable script.
  const p = projectPaths(job);
  fs.writeFileSync(path.join(p.root, 'script.txt'), segments.map((s) => s.text).join('\n'), 'utf8');

  project.steps.roughCut = true;
  saveProject(job, project);

  const pct = duration ? Math.round((keptDur / duration) * 100) : 0;
  console.log(`\n✓ Rough cut complete`);
  console.log(`  ${duration.toFixed(1)}s  →  ${keptDur.toFixed(1)}s  (${pct}% kept, ${segments.length} segments)`);
  console.log(`  timeline: projects/${job}/timeline.json`);
  console.log(`  script:   projects/${job}/script.txt`);

  if (!bool(flags['no-preview'])) {
    const smooth = cfg.render?.smoothCuts !== false;
    console.log(`\nRendering preview (${smooth ? 'smooth cross-dissolves' : 'hard cuts'})...`);
    const spansOut = segments.map((s) => ({ in: s.sourceIn, out: s.sourceOut }));
    await renderPreview(job, spansOut, timeline.fps, cfg);
    console.log(`  preview:  projects/${job}/preview.mp4`);
  }
  console.log(`\nReview the cut, then:  graphics →  node scripts/build-composition.mjs --job ${job}\n`);
}

main().catch((e) => { console.error('\nRough cut failed:', e.message); process.exit(1); });
