---
name: export
description: Step 7 of the video pipeline. Finalize the edit — promote the most advanced version to outputs/<job>.final.mp4 and drop a copy in Downloads, with a final loudness pass. Use when the user says "export", "finish it", "render the final", or "ship it".
---

# Export — finalize and ship

Step 7. Picks the most advanced artifact (music > captions > graphics > rough cut), applies a final loudness pass (skipped if music already normalized), and writes `outputs/<job>.final.mp4` plus a copy in Downloads. The project is left fully intact for re-editing.

## Do this

```bash
node scripts/finalize.mjs --job <job>
```

- `--no-copy` skips the Downloads copy.

Report both paths back to the user. Confirm the final plays correctly.

## Optional: thumbnail
For long-form especially, offer a thumbnail (**thumbnail** skill):

```bash
node scripts/thumbnail.mjs --job <job> --title "Big Idea" --time 4
```

## Re-editing later
Nothing is destroyed on export. To change something, edit `timeline.json` / `plan.json` and re-run the relevant step — the segment cache keeps re-renders fast — then export again.
