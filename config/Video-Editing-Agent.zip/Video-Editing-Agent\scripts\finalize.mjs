#!/usr/bin/env node
// Step 7 — Export. Promotes the most advanced artifact to outputs/<job>.final.mp4
// and drops a copy in Downloads. The project is left fully intact for re-editing.
//
// Usage: node scripts/finalize.mjs [--job name] [--no-copy]
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { parseArgs, bool } from '../lib/args.mjs';
import { loadConfig, DIRS, ensureDir } from '../lib/paths.mjs';
import { loudnorm } from '../lib/ffmpeg.mjs';
import { resolveJob, loadProject, saveProject, latestVideo } from '../lib/project.mjs';

async function main() {
  const { flags } = parseArgs();
  const cfg = loadConfig();
  const job = resolveJob(flags.job);
  const project = loadProject(job);

  const input = latestVideo(job);
  if (!input) { console.error('Nothing to export — run the pipeline first.'); process.exit(1); }

  ensureDir(DIRS.outputs);
  const finalOut = path.join(DIRS.outputs, `${job}.final.mp4`);

  if (project.steps?.music) {
    // Music step already ended on the final loudness target — just copy.
    fs.copyFileSync(input, finalOut);
  } else {
    // No music: apply a final loudness pass so exports are consistent.
    const lufs = cfg.audio?.finalLoudnessLUFS ?? -14;
    console.log(`Final loudness normalize to ${lufs} LUFS...`);
    await loudnorm(input, finalOut, lufs, cfg);
  }

  // Copy to Downloads (like the reference).
  let downloadCopy = null;
  if (!bool(flags['no-copy'])) {
    const dl = cfg.paths?.downloads && fs.existsSync(cfg.paths.downloads)
      ? cfg.paths.downloads : path.join(os.homedir(), 'Downloads');
    if (fs.existsSync(dl)) {
      downloadCopy = path.join(dl, `${job}.final.mp4`);
      fs.copyFileSync(finalOut, downloadCopy);
    }
  }

  project.steps.export = true;
  project.exportedAt = new Date().toISOString();
  saveProject(job, project);

  console.log(`\n✓ Exported`);
  console.log(`  final:     outputs/${job}.final.mp4`);
  if (downloadCopy) console.log(`  copy:      ${downloadCopy}`);
  console.log(`  from step: ${path.basename(input)}`);
  console.log(`  project left intact — re-edit any time, then export again.\n`);
}

main().catch((e) => { console.error('\nExport failed:', e.message); process.exit(1); });
