---
name: graphics-plan
description: Step 3 of the video pipeline. Plan and render motion graphics onto the cut — title cards, lower-thirds, keyword pops, bullet lists, stats, and image/logo overlays via the HyperFrames engine, styled per format. Use when the user says "do the graphics", "add motion graphics", "make it visual", or after the rough cut is locked.
---

# Graphics — plan a beat per segment, then render

Step 3. Reads `timeline.json`, writes `plan.json` (which graphic goes on which segment), merges it into the timeline, and renders the composited video. Format-specific: cards go top-half for `short-explainer`, glass panels for `long-form-youtube`, a hook card for `tiktok-raw`.

## Fast path (auto first pass)

```bash
node scripts/build-composition.mjs --job <job>
```

If no `plan.json` exists it drafts a conservative one (a lower-third keyword on longer segments), renders, and leaves `work/composited.mp4`. Good for a first look — but the real quality comes from authoring the plan yourself (below).

## Authoring good graphics (do this for quality)

1. Read `projects/<job>/timeline.json`. Each segment has `id`, `text`, `duration`, `sourceIn/out`.
2. Decide, per segment, whether it earns a graphic and which type. Don't put a graphic on every segment — rhythm beats clutter. Emphasize: key claims, numbers, lists, names/brands, and the hook.
3. Write `projects/<job>/plan.json`:

```json
{
  "job": "<job>",
  "format": "<format>",
  "segments": [
    { "id": "seg-0001", "graphic": { "type": "title-card", "eyebrow": "THE PROBLEM", "title": "Why you stay stuck" } },
    { "id": "seg-0002", "graphic": null },
    { "id": "seg-0003", "graphic": { "type": "keyword", "title": "Momentum", "motion": "pop" } },
    { "id": "seg-0004", "graphic": { "type": "bullets", "title": "Three traps", "items": ["Perfectionism", "No feedback loop", "Comparison"] } },
    { "id": "seg-0005", "graphic": { "type": "stat", "value": "90%", "label": "quit in week one" } },
    { "id": "seg-0006", "graphic": { "type": "image", "src": "claude-mascot.png", "title": "Claude", "float": true } }
  ]
}
```

### Graphic spec fields
- `type`: `title-card` | `lower-third` | `keyword` | `bullets` | `stat` | `image` | `none`
- `title`, `subtitle`, `eyebrow` — text (by type)
- `items` — array for `bullets`
- `value` + `label` — for `stat`
- `src` — filename in `assets/` (or `assets/logos/`) for `image`
- `motion`: `slideUp` | `slideLeft` | `slideRight` | `pop` | `fade` (default from the style)
- `rect`: `[x,y,w,h]` normalized 0–1 to override the format's default graphic zone (e.g. move a card off the speaker's face)
- `start` (s into segment), `duration` (s), `float` (gentle bob), `color`, `size`

4. Render:

```bash
node scripts/build-composition.mjs --job <job>
```

It uses your `plan.json` (won't redraft). Then open `work/composited.mp4`.

## Notes
- The **first** render launches headless Chrome per graphic segment (and every segment for `short-explainer`, which composites the whole frame) — it can take a while. Subsequent edits are fast because each segment is cached by a content hash.
- To move logos/PNGs in, drop them in `assets/` and reference by filename in an `image` graphic.
- When a first pass is up, switch to the **second-pass** skill to refine graphics one by one.
