---
name: captions
description: Step 5 of the video pipeline. Burn word-timed captions onto short-form videos — progressive word reveal, box-behind, accent highlight, styled per format (centered/locked for explainer, low under the face for tiktok-raw). Use when the user says "add captions", "add subtitles", or is finishing a short-form edit.
---

# Captions — word-timed burn-in (short-form)

Step 5. Only for short-form (`short-explainer`, `tiktok-raw`). Long-form uses YouTube CC, so this step no-ops there unless forced.

Captions come from the same WhisperX transcript already in the project (no re-transcribe), mapped into the **cut** timeline, so they land on-beat.

## Do this

```bash
node scripts/captions.mjs --job <job>
```

- Burns onto the most advanced video (graphics `composited.mp4`, else the rough-cut `preview.mp4`) → `work/captioned.mp4`.
- Style comes from `presets/styles/captions.json`: font (Coolvetica if you drop `Coolvetica.ttf` in `assets/fonts/`, else Arial Black fallback), size, box opacity, accent color, words-per-line.

## Tweaks
- Wrong brand spelling in captions (e.g. "clod" → "Claude")? Add it to `presets/caption-corrections.json` `replacements`, then re-run.
- Too many/few words per line, or size/position: edit `presets/styles/captions.json` (`maxWordsPerLine`, `fontSizePct`) or the format's `captions.alignment`/`marginVPct`, then re-run.
- `--force` burns captions even on a long-form format if the user insists.

The reference look = Coolvetica font, black box behind, words revealing on-beat with the current word in the accent color. Point the user to drop `Coolvetica.ttf` into `assets/fonts/` to match it exactly.

Next: **background-music** (optional) or **export**.
