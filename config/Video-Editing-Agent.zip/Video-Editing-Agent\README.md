# 🎬 Claude Video Editing Agent

Drop in raw footage. Claude edits the whole thing — cuts the dead space, adds motion graphics, burns captions, mixes music, and exports a finished video. End to end, on your machine.

Built on the open-source [**HyperFrames**](https://github.com/heygen-com/hyperframes) HTML-to-video engine and [**WhisperX**](https://github.com/m-bain/whisperX) word-level transcription. Windows-native, deterministic, and incremental.

---

## Why this one is different

- **Windows-native.** Pure Node scripts — no bash, no WSL. It just runs.
- **Incremental re-renders.** Every segment is cached by a content hash. Change one graphic and *only that segment* re-renders — the rest is instant. Second-pass edits take seconds, not a full re-render.
- **One source of truth.** A single `timeline.json` per project drives every step. Edits are transparent and reversible.
- **Word-accurate.** WhisperX word-level timestamps drive both the cuts and the on-beat captions.
- **Self-checking.** `node scripts/doctor.mjs` tells you exactly what's healthy or missing.

## The pipeline (7 steps)

```
1 Intake     copy raw clip → projects/<job>/raw/
2 Rough cut  WhisperX transcribe → auto-cut silence + filler → preview
3 Graphics   plan a beat per segment → render motion graphics (HyperFrames)
4 Second pass  refine graphics with plain-language tweaks (incremental)
5 Captions   word-timed burn-in (short-form only)
6 Music      ducked background track + loudness normalize (optional)
7 Export     outputs/<job>.final.mp4 (+ a copy in Downloads)
```

Only steps **3** and **5** change between formats.

## Formats

| Format | Ratio | Graphics | Captions |
|---|---|---|---|
| `long-form-youtube` | 16:9 | glass cards float over full-frame face | YouTube CC (not burned) |
| `short-explainer` | 9:16 | cards top-half, face bottom-half | centered, locked |
| `tiktok-raw` | 9:16 | hook card, otherwise raw | low, under the face |

---

## Setup (one time)

**Prerequisites already needed:** [Node.js ≥ 22](https://nodejs.org), [uv](https://docs.astral.sh/uv/), and (Windows) `winget`.

```bash
npm run setup
```

That installs the rest and verifies it:
- **ffmpeg** (via winget `Gyan.FFmpeg`)
- **Python 3.11 + WhisperX** into `engine/whisperx/.venv` (via uv, CPU/`int8`)
- **HyperFrames** (npm) + a scaffolded render project in `engine/hyperframes/`

Check health any time:

```bash
node scripts/doctor.mjs
```

> **GPU note:** this machine has integrated graphics, so WhisperX runs on CPU. Transcribing long clips is slow — test on a short slice first, or leave it running.

---

## Usage

Talk to Claude in this folder ("here's my raw clip, do the rough cut", "add graphics", "move that card to the bottom", "add captions", "export"). Claude uses the skills in `.claude/skills/`. Or run the steps yourself:

```bash
# 1. Intake
node scripts/intake.mjs "C:/path/to/raw.mp4"

# 2. Rough cut (transcribe + auto-cut + preview)
node scripts/rough-cut.mjs

# 3. Graphics (auto first pass, then refine plan.json)
node scripts/build-composition.mjs

# 4. Second pass — edit projects/<job>/plan.json, then re-render (only changed segments)
node scripts/build-composition.mjs

# 5. Captions (short-form)
node scripts/captions.mjs

# 6. Music (optional)
node scripts/music.mjs --music "C:/path/to/track.mp3" --level -23

# 7. Export
node scripts/finalize.mjs
```

Handy:

```bash
node scripts/cli.mjs list            # projects + progress
node scripts/cli.mjs status <job>    # step checklist
node scripts/prune.mjs               # reclaim disk (keeps the cache)
```

---

## Customize

- **Graphics content** — author `projects/<job>/plan.json` (schema in the `graphics-plan` skill). Types: `title-card`, `lower-third`, `keyword`, `bullets`, `stat`, `image`, `none`.
- **Look** — edit `presets/styles/*.json` (colors, fonts, motion) and `presets/formats/*.json` (canvas, layout, zones).
- **Cut behavior** — `config.json` → `roughCut` (silence threshold, filler lists, padding).
- **Audio targets** — `config.json` → `audio` (voice/music/final LUFS, ducking).
- **Assets you supply** (licensed, so not bundled):
  - Logos / PNGs → `assets/` — reference by filename in an `image` graphic.
  - **Coolvetica** font → `assets/fonts/Coolvetica.ttf` to match the reference caption look (falls back to Arial Black otherwise).
- **Caption fixes** — brand/spelling corrections in `presets/caption-corrections.json`.

## Folder structure

```
CLAUDE.md            master guide Claude follows
config.json          global defaults
.claude/skills/      the 9 pipeline skills
lib/                 shared helpers (ffmpeg, whisperx, project, hashing, composition)
scripts/             the pipeline (one script per step)
presets/formats/     short-explainer · tiktok-raw · long-form-youtube
presets/styles/      signature · liquid-glass · tiktok-raw · captions
engine/hyperframes/  HyperFrames render project (graphics engine)
engine/whisperx/     WhisperX venv (transcription)
assets/              your logos / fonts
projects/<job>/      per-video workspace (raw, timeline.json, plan.json, segments cache…)
outputs/             finished <job>.final.mp4
```

## Troubleshooting

- **ffmpeg "not found" right after install** — winget doesn't refresh a running shell's PATH; the scripts auto-discover it in the winget location, so it usually works anyway. If not, open a new terminal.
- **HyperFrames can't launch Chrome** — run `node_modules/.bin/hyperframes browser install` once.
- **WhisperX first run downloads models** — expected, one-time (~1–3 GB).
- **Graphics render is slow the first time** — it launches headless Chrome per graphic segment; subsequent edits use the cache. `short-explainer` composites every segment, so its first pass is the slowest.

## Credits & license

- Graphics engine: [HyperFrames](https://github.com/heygen-com/hyperframes) (Apache-2.0).
- Transcription: [WhisperX](https://github.com/m-bain/whisperX).
- This orchestration layer is yours to modify. Fonts, logos, and music you add are governed by their own licenses.
