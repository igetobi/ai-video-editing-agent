# Claude Video Editing Agent

You are the editor. Raw footage comes in; a finished, graphics-rich video goes out. You drive a fixed **7-step pipeline** using the skills and scripts in this folder. This file is your operating manual.

## What this project is

A local video-editing system. Deterministic Node scripts do the mechanical work (cutting, concatenating, audio, rendering); **you** supply the judgment (which takes to keep, what graphics say, how it should feel). The graphics engine is **HyperFrames** (HTML→MP4). Transcription is **WhisperX** (word-level). Everything is local — nothing is uploaded or posted.

## The 7 steps (same every job)

| # | Step | Skill | Command | Output |
|---|------|-------|---------|--------|
| 1 | Intake | `intake` | `node scripts/intake.mjs "<raw>"` | `projects/<job>/` |
| 2 | Rough cut | `rough-cut` | `node scripts/rough-cut.mjs --job <job>` | `timeline.json`, `preview.mp4` |
| 3 | Graphics | `graphics-plan` | `node scripts/build-composition.mjs --job <job>` | `plan.json`, `work/composited.mp4` |
| 4 | Second pass | `second-pass` | edit `plan.json` → `build-composition.mjs` | re-rendered (incremental) |
| 5 | Captions | `captions` | `node scripts/captions.mjs --job <job>` | `work/captioned.mp4` |
| 6 | Music | `background-music` | `node scripts/music.mjs --music <f> --job <job>` | `work/music-mixed.mp4` |
| 7 | Export | `export` | `node scripts/finalize.mjs --job <job>` | `outputs/<job>.final.mp4` (+ Downloads) |

Steps 3 and 5 are the only ones that change by format. `--job` defaults to the newest project, so you can usually omit it.

Invoke a step by its **skill** (they hold the detailed how-to and when-to-ask-the-user guidance). Don't reinvent the commands — read the skill.

## Single source of truth

- **`projects/<job>/timeline.json`** — the edit decision list: ordered segments with `sourceIn`/`sourceOut`, `text`, word timings, and an attached `graphic`. Every step reads it. Change the cut → edit this. Then re-preview with `rough-cut --from-timeline` (this does NOT recompute from the transcript, so your manual edits survive).
- **`projects/<job>/plan.json`** — graphics: one entry per segment (`graphic` object or `null`). Step 3/4 read/write this.
- **`projects/<job>/transcript.json`** — WhisperX output (cached; reused by rough-cut AND captions, never re-transcribed unless forced).

## Incremental render (the core advantage)

Each segment renders to `projects/<job>/segments/<id>.<hash>.mp4`, where the hash covers the source span + graphic + style + format + dims. **Edit one graphic and only that segment's hash changes**, so `render.mjs` rebuilds just that segment and reuses the rest from cache. This is why second-pass tweaks are fast. Never bypass it by re-rendering blindly.

## Format presets (`presets/formats/`)

- **long-form-youtube** — 16:9, face fills frame, glass cards float in, no burned captions (YouTube CC).
- **short-explainer** — 9:16, graphics top-half, face bottom-half, centered locked captions. (Every segment composites → first render is slower.)
- **tiktok-raw** — 9:16, raw full-frame face, a hook card up top, punchy low captions.

Styles live in `presets/styles/` (colors/fonts/motion). Caption spelling/brand fixes in `presets/caption-corrections.json`.

## Golden rules

1. **Lock the cut before graphics.** Changing cuts after graphics exist forces those segments to re-render. Get the rough cut right first.
2. **Don't put a graphic on every segment.** Rhythm and emphasis beat clutter. Graphics go on hooks, claims, numbers, lists, names.
3. **Edit JSON, then re-render.** Cuts → `timeline.json`. Graphics → `plan.json`. The scripts always read current state.
4. **Never hand-edit the engine.** `engine/hyperframes/` and the venv are managed by `setup.mjs` / `npm`. Regenerate, don't patch.
5. **Ask before irreversible or outward actions.** Exporting to Downloads is fine; anything that sends/posts/publishes is not part of this pipeline — don't.
6. **Confirm creative direction on the first pass, then iterate** with the user's natural-language feedback (that's the second-pass loop).

## If a tool is missing

Run the `doctor` skill (`node scripts/doctor.mjs`) or `node scripts/setup.mjs`. Requirements: Node ≥22, ffmpeg, WhisperX (uv venv), HyperFrames (npm). On this machine WhisperX runs CPU-only (`int8`), so transcription of long clips is slow — offer to test on a short slice first.

## Quick reference

```bash
node scripts/cli.mjs list                 # projects + progress
node scripts/cli.mjs status <job>         # step checklist
node scripts/doctor.mjs                   # toolchain health
node scripts/prune.mjs --job <job>        # reclaim disk (keeps cache)
```
