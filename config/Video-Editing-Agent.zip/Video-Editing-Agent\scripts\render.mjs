#!/usr/bin/env node
// Segment renderer. Each segment is cached by a content hash of (source span +
// graphic + style + format + dims/fps). Edit one graphic and only that segment's
// hash changes, so only it re-renders — every other segment is reused from cache.
// Then all segments concat into work/composited.mp4.
//
// Usage: node scripts/render.mjs [--job name]
import fs from 'node:fs';
import path from 'node:path';
import { parseArgs } from '../lib/args.mjs';
import { loadConfig, resolveTool, hyperframesEntry, ensureDir, DIRS } from '../lib/paths.mjs';
import { must } from '../lib/exec.mjs';
import { segmentHash } from '../lib/hash.mjs';
import { cutSegment, normalize, concatDemux } from '../lib/ffmpeg.mjs';
import { buildSegmentComposition } from '../lib/composition.mjs';
import { loadFormat, resolveStyleFor } from '../lib/presets.mjs';
import {
  resolveJob, projectPaths, sourceFile, loadTimeline, loadProject, saveProject,
} from '../lib/project.mjs';

function hfEnv(cfg) {
  const f = resolveTool('ffmpeg', cfg);
  const env = { ...process.env };
  if (f) env.PATH = path.dirname(f) + path.delimiter + (env.PATH || '');
  return env;
}

function resolveAsset(src) {
  if (!src) return null;
  const tries = [src, path.join(DIRS.assets, src), path.join(DIRS.assets, 'logos', src), path.resolve(src)];
  for (const t of tries) if (fs.existsSync(t)) return path.resolve(t);
  return null;
}

export async function renderTimeline(job, cfg = loadConfig()) {
  const timeline = loadTimeline(job);
  if (!timeline?.segments?.length) throw new Error('Timeline is empty. Run the rough cut first.');
  const format = loadFormat(timeline.format);
  const { name: styleName, style } = resolveStyleFor(format, timeline.style);
  const canvas = { width: timeline.dims.width, height: timeline.dims.height, fps: timeline.fps };
  const src = sourceFile(job);
  const p = projectPaths(job);
  ensureDir(p.segments); ensureDir(p.composition); ensureDir(p.work);
  const hfEntry = hyperframesEntry();
  const layoutComposite = format.layout === 'composite';

  // Hash-invariant part of the format that affects a segment's look.
  const formatKey = {
    name: format.name, layout: format.layout, bg: format.bg || '#000',
    videoRect: format.video?.rect || null, baseFit: format.baseFit || 'cover',
    graphicZone: format.graphicZone?.rect || null,
    w: canvas.width, h: canvas.height,
  };

  const files = [];
  let rebuilt = 0, cached = 0;
  for (const seg of timeline.segments) {
    const graphic = seg.graphic || null;
    const needHF = !!graphic || layoutComposite;
    const hash = segmentHash({
      sourceFile: src, sourceIn: seg.sourceIn, sourceOut: seg.sourceOut,
      graphic, style: { name: styleName, s: style }, format: formatKey, fps: canvas.fps,
    });
    const outFile = path.join(p.segments, `${seg.id}.${hash}.mp4`);

    if (fs.existsSync(outFile)) { files.push(outFile); cached++; continue; }

    const durationSec = seg.sourceOut - seg.sourceIn;
    process.stdout.write(`  rendering ${seg.id} (${needHF ? 'graphics' : 'cut'})...\n`);

    if (!needHF) {
      await cutSegment(src, seg.sourceIn, seg.sourceOut, outFile,
        { width: canvas.width, height: canvas.height, fps: canvas.fps, fit: format.baseFit || 'cover' }, cfg);
    } else {
      if (!hfEntry) throw new Error('hyperframes CLI missing. Run `npm install`.');
      const compDir = path.join(p.composition, `${seg.id}.${hash}`);
      ensureDir(compDir);
      const baseSpan = path.join(compDir, 'seg-src.mp4');
      // Composite layouts place the video into a sub-rect and crop it via CSS
      // object-fit, so feed source-dims here (cropping to canvas first would
      // double-crop). Overlay layouts fill the canvas, so pre-fit to canvas.
      const baseOpts = layoutComposite
        ? { fps: canvas.fps }
        : { width: canvas.width, height: canvas.height, fps: canvas.fps, fit: format.baseFit || 'cover' };
      await cutSegment(src, seg.sourceIn, seg.sourceOut, baseSpan, baseOpts, cfg);

      let g = graphic;
      if (graphic && graphic.type === 'image' && graphic.src) {
        const asset = resolveAsset(graphic.src);
        if (asset) {
          ensureDir(path.join(compDir, 'assets'));
          const rel = 'assets/' + path.basename(asset);
          fs.copyFileSync(asset, path.join(compDir, rel));
          g = { ...graphic, assetRel: rel };
        } else {
          console.warn(`    ! image asset not found: ${graphic.src} (skipping image)`);
          g = { ...graphic, type: 'title-card', title: graphic.title || '' };
        }
      }

      buildSegmentComposition({
        dir: compDir, segId: seg.id, durationSec, canvas,
        bg: format.bg || '#000000',
        videoRect: format.video?.rect || null,
        baseVideoRel: 'seg-src.mp4',
        graphic: g,
        graphicZone: format.graphicZone?.rect,
        style,
      });

      const hfOut = path.join(compDir, 'render.mp4');
      await must(process.execPath, [hfEntry, 'render', compDir, '-o', hfOut, '-f', String(canvas.fps), '--quality', 'standard', '--quiet'],
        { env: hfEnv(cfg) });
      // Mux the authoritative cut audio (from baseSpan) over the HF video + normalize.
      await normalize(hfOut, outFile,
        { width: canvas.width, height: canvas.height, fps: canvas.fps, fit: 'cover', audioFrom: baseSpan }, cfg);
    }
    files.push(outFile);
    rebuilt++;
  }

  await concatDemux(files, p.composited, cfg);

  const project = loadProject(job);
  project.steps.graphics = true;
  saveProject(job, project);

  return { composited: p.composited, rebuilt, cached, total: timeline.segments.length };
}

// Run directly
if (process.argv[1]?.endsWith('render.mjs')) {
  const { flags } = parseArgs();
  const cfg = loadConfig();
  const job = resolveJob(flags.job);
  console.log(`Rendering ${job}...`);
  renderTimeline(job, cfg)
    .then((r) => {
      console.log(`\n✓ Render complete — ${r.rebuilt} rebuilt, ${r.cached} cached (${r.total} segments)`);
      console.log(`  output: projects/${job}/work/composited.mp4\n`);
    })
    .catch((e) => { console.error('\nRender failed:', e.message); process.exit(1); });
}
