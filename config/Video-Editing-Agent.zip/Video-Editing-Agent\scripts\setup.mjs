#!/usr/bin/env node
// One-shot environment setup. Idempotent: each step is skipped if already done.
// Installs ffmpeg (winget), Python 3.11 + WhisperX (uv), and HyperFrames (npm),
// then scaffolds the render project and runs the doctor.
import fs from 'node:fs';
import path from 'node:path';
import { stream, capture } from '../lib/exec.mjs';
import { abs, resolveTool, hyperframesEntry, IS_WIN, loadConfig } from '../lib/paths.mjs';
import { whisperxBin } from '../lib/whisperx.mjs';

const cfg = loadConfig();
const step = (n, msg) => console.log(`\n[setup ${n}] ${msg}`);
const have = (cmd) => capture(IS_WIN ? 'where' : 'which', [cmd]).ok;

async function main() {
  console.log('Video Editing Agent — setup\n===========================');

  // 1. ffmpeg
  step(1, 'ffmpeg');
  if (resolveTool('ffmpeg', cfg)) {
    console.log('  already installed:', resolveTool('ffmpeg', cfg));
  } else if (IS_WIN && have('winget')) {
    await stream('winget', ['install', '-e', '--id', 'Gyan.FFmpeg',
      '--accept-source-agreements', '--accept-package-agreements', '--disable-interactivity'], { shell: true });
  } else {
    console.log('  Please install ffmpeg manually (macOS: `brew install ffmpeg`, Linux: apt/dnf).');
  }

  // 2. Python + WhisperX via uv
  step(2, 'Python 3.11 + WhisperX (uv)');
  if (whisperxBin()) {
    console.log('  WhisperX already installed:', whisperxBin());
  } else if (have('uv')) {
    await stream('uv', ['python', 'install', '3.11']);
    const venv = abs('engine', 'whisperx', '.venv');
    if (!fs.existsSync(venv)) await stream('uv', ['venv', venv, '--python', '3.11']);
    const venvPy = IS_WIN ? path.join(venv, 'Scripts', 'python.exe') : path.join(venv, 'bin', 'python');
    console.log('  installing whisperx (large download, one time)...');
    await stream('uv', ['pip', 'install', '--python', venvPy, 'whisperx']);
  } else {
    console.log('  `uv` not found. Install uv from https://docs.astral.sh/uv/ then re-run setup.');
  }

  // 3. HyperFrames CLI
  step(3, 'HyperFrames (npm)');
  if (hyperframesEntry()) {
    console.log('  already installed.');
  } else {
    // npm is a .cmd shim on Windows — run via shell (args have no spaces; cwd is passed separately).
    await stream('npm', ['install'], { cwd: abs('.'), shell: true });
  }

  // 4. HyperFrames render project
  step(4, 'HyperFrames render project (engine/hyperframes)');
  if (fs.existsSync(abs('engine', 'hyperframes', 'index.html'))) {
    console.log('  already scaffolded.');
  } else {
    const hf = hyperframesEntry();
    if (hf) {
      await stream(process.execPath, [hf, 'init', 'engine/hyperframes', '--example', 'blank', '--non-interactive', '--skip-transcribe'],
        { cwd: abs('.'), env: { ...process.env, HYPERFRAMES_SKIP_SKILLS: '1' } });
    }
  }

  // 5. Doctor
  step(5, 'Verifying');
  await stream(process.execPath, [abs('scripts', 'doctor.mjs')], { cwd: abs('.') });
}

main().catch((e) => { console.error('\nSetup failed:', e.message); process.exit(1); });
