---
name: rough-cut
description: Step 2 of the video pipeline. Transcribe raw footage with WhisperX and auto-cut it into a tight edit — removing silences, filler words, and dead space using word-level timestamps — then render a preview. Use when the user says "do the rough cut", "cut it down", "trim the dead space", or wants a first tight edit.
---

# Rough cut — transcribe + auto-cut

Step 2 of the pipeline. Produces `timeline.json` (the single source of truth for the edit) and a `preview.mp4`.

## Do this

```bash
node scripts/rough-cut.mjs --job <job>
```

- First run transcribes with WhisperX (CPU here — a few minutes for a short clip, longer for long-form). It caches `transcript.json`, so re-runs are fast.
- Removes long silences and standalone filler ("um, uh, mm…"). Because a span breaks at every removed word, filler audio is never left in the seam.
- Writes `timeline.json`, a human-readable `script.txt`, and renders `preview.mp4`.

Flags:
- `--aggressive` — also remove hedge words (like, you know, basically, actually…). Use only if the user wants a very tight edit; it can clip meaning.
- `--force-transcribe` — re-transcribe from scratch.
- `--no-preview` — skip rendering (just compute the timeline).

## Then refine (this is where judgment matters)

Read `script.txt` (the whole cut as text) end-to-end and hunt for **bad takes / restarts** — places the speaker re-said a line ("Number one, the number one, the first…", "many people they undervalue month… overvalue money…"). The auto-pass removes silence + filler but *keeps every word*, so restarts remain. This is the step that separates a clean edit from raw footage.

**Preferred: a re-runnable cut-list.** Create `projects/<job>/excludes.json` describing the words to drop, then re-run rough-cut (it reuses the cached transcript, so it's fast):

```json
{ "excludes": [
  "and one of the bad",                                     // exact word run (first match)
  "number one the number one",                              // keeps "the first bad pattern…"
  { "from": "many people they don't use most",
    "to":   "they overvalue money and they undervalue time" }, // cut everything between two anchors
  { "start": 128.4, "end": 131.0 }                          // or an explicit source-time range
] }
```

```bash
node scripts/rough-cut.mjs --job <job>
```

It prints which phrases matched (✓) or weren't found (✗ — fix the wording). Anchors are matched on words with punctuation/case ignored. This keeps the cut declarative and reversible — edit the list, re-run.

**Also watch for:** cuts too tight (a word clipped) → nudge `config.roughCut.keepPaddingSec`, or hand-edit `sourceIn`/`sourceOut` in `timeline.json` and re-preview with `--from-timeline` (that preserves manual edits; the plain command recomputes and would overwrite them).

## Smooth cuts (no visible jumps)

Every seam gets a short audio crossfade + video cross-dissolve so talking-head jump-cuts are invisible. Controlled in `config.json` → `render.smoothCuts` (default true) and `render.transitionSec` (default 0.13s ≈ 4 frames). Lower it for snappier cuts, raise it for softer blends; set `smoothCuts:false` for hard cuts.

**Lock the cut before moving on** — changing cuts after graphics exist means re-rendering those segments. When the user is happy, go to the **graphics-plan** skill.
