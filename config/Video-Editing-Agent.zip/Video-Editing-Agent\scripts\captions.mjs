#!/usr/bin/env node
// Step 5 — Captions (short-form). Builds word-timed ASS subtitles from the
// transcript, mapped into the CUT timeline (composited seconds, not source),
// then burns them in with libass. Progressive word reveal, box-behind, accent
// highlight on the current word. Long-form formats skip this (use YT CC).
//
// Usage: node scripts/captions.mjs [--job name] [--force]
import fs from 'node:fs';
import path from 'node:path';
import { parseArgs, bool } from '../lib/args.mjs';
import { loadConfig, resolveTool, ensureDir } from '../lib/paths.mjs';
import { stream } from '../lib/exec.mjs';
import { loadFormat, loadStyle, loadCaptionCorrections } from '../lib/presets.mjs';
import {
  resolveJob, projectPaths, loadTimeline, loadProject, saveProject,
} from '../lib/project.mjs';

// --- ASS helpers -----------------------------------------------------------
function assColor(hex, alpha = 0) {
  const h = String(hex).replace('#', '');
  const r = h.slice(0, 2), g = h.slice(2, 4), b = h.slice(4, 6);
  const a = Math.max(0, Math.min(255, alpha)).toString(16).padStart(2, '0');
  return `&H${a}${b}${g}${r}`.toUpperCase();
}
function assTime(t) {
  const cs = Math.max(0, Math.round(t * 100));
  const h = Math.floor(cs / 360000);
  const m = Math.floor((cs % 360000) / 6000);
  const s = Math.floor((cs % 6000) / 100);
  const c = cs % 100;
  return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(c).padStart(2, '0')}`;
}
const assEsc = (s) => String(s).replace(/[{}]/g, '').replace(/\n/g, ' ');

// Map every kept word onto composited-timeline seconds.
function compositedWords(timeline, corrections) {
  const rep = corrections.replacements || {};
  const words = [];
  let offset = 0;
  for (const seg of timeline.segments) {
    const segDur = seg.sourceOut - seg.sourceIn;
    for (const w of seg.words || []) {
      let text = w.word;
      const key = text.toLowerCase().replace(/[^a-z0-9']/g, '');
      if (rep[key]) text = text.replace(/[A-Za-z0-9']+/, rep[key]);
      words.push({
        text,
        start: offset + (w.start - seg.sourceIn),
        end: offset + (w.end - seg.sourceIn),
        segId: seg.id,
      });
    }
    offset += segDur;
  }
  return words;
}

function groupLines(words, maxWords, maxDur) {
  const lines = [];
  let cur = [];
  for (const w of words) {
    cur.push(w);
    const dur = w.end - cur[0].start;
    const sentence = /[.!?]$/.test(w.text);
    if (cur.length >= maxWords || dur >= maxDur || sentence) { lines.push(cur); cur = []; }
  }
  if (cur.length) lines.push(cur);
  return lines;
}

function buildAss(words, canvas, capStyle, fmtCap) {
  const H = canvas.height, W = canvas.width;
  const fontSize = Math.round((capStyle.fontSizePct ?? 0.055) * H);
  const primary = assColor(capStyle.primary || '#FFFFFF', 0);
  const accent = assColor(capStyle.accent || '#D97757', 0);
  const boxAlpha = Math.round((1 - (capStyle.boxOpacity ?? 0.85)) * 255);
  const box = assColor(capStyle.box || '#000000', boxAlpha);
  const align = fmtCap.alignment ?? 5;
  const marginV = Math.round((fmtCap.marginVPct ?? 0) * H);
  const font = capStyle.fontName || 'Arial Black';
  const bold = capStyle.bold === false ? 0 : -1;
  const upper = capStyle.uppercase !== false;
  const outline = capStyle.boxPadding ?? 14;

  const header =
`[Script Info]
ScriptType: v4.00+
PlayResX: ${W}
PlayResY: ${H}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,${font},${fontSize},${primary},${primary},${box},${box},${bold},0,0,0,100,100,0,0,3,${outline},0,${align},80,80,${marginV},1

[Events]
Format: Layer, Start, End, Style, MarginL, MarginR, Effect, Text`;

  const maxWords = capStyle.maxWordsPerLine ?? 4;
  const maxDur = capStyle.maxLineDurSec ?? 2.4;
  const lines = groupLines(words, maxWords, maxDur);
  const events = [];
  for (let li = 0; li < lines.length; li++) {
    const line = lines[li];
    const nextLineStart = lines[li + 1]?.[0]?.start ?? (line[line.length - 1].end + 0.4);
    for (let k = 0; k < line.length; k++) {
      const evStart = line[k].start;
      const evEnd = k < line.length - 1 ? line[k + 1].start : nextLineStart;
      if (evEnd <= evStart) continue;
      const parts = line.slice(0, k + 1).map((w, j) => {
        const t = upper ? w.text.toUpperCase() : w.text;
        return j === k ? `{\\c${accent}}${assEsc(t)}{\\c${primary}}` : assEsc(t);
      });
      const text = `{\\fad(50,0)}` + parts.join(' ');
      events.push(`Dialogue: 0,${assTime(evStart)},${assTime(evEnd)},Cap,80,80,0,,${text}`);
    }
  }
  return header + '\n' + events.join('\n') + '\n';
}

async function main() {
  const { flags } = parseArgs();
  const cfg = loadConfig();
  const job = resolveJob(flags.job);
  const p = projectPaths(job);
  const timeline = loadTimeline(job);
  const format = loadFormat(timeline.format);
  const fmtCap = format.captions || { enabled: false };

  if (!fmtCap.enabled && !bool(flags.force)) {
    console.log(`Format "${timeline.format}" doesn't use burned-in captions (long-form uses YouTube CC).`);
    console.log('Pass --force to burn them anyway.\n');
    return;
  }

  const capStyle = loadStyle('captions');
  // Only use the primary caption font if a matching file is bundled; otherwise
  // fall back to a name libass can actually resolve on this machine.
  const fontsSrcDir = path.join(process.cwd(), 'assets', 'fonts');
  const hasPrimaryFont = fs.existsSync(fontsSrcDir) &&
    fs.readdirSync(fontsSrcDir).some((f) => f.toLowerCase().includes(String(capStyle.fontName || '').toLowerCase()) && /\.(ttf|otf)$/i.test(f));
  if (!hasPrimaryFont && capStyle.fontFallback) capStyle.fontName = capStyle.fontFallback;
  const corrections = loadCaptionCorrections();
  const words = compositedWords(timeline, corrections);
  if (!words.length) { console.error('No word timings available for captions.'); process.exit(1); }

  const canvas = { width: timeline.dims.width, height: timeline.dims.height };
  const ass = buildAss(words, canvas, capStyle, fmtCap);
  ensureDir(p.work);
  fs.writeFileSync(path.join(p.work, 'captions.ass'), ass, 'utf8');

  // Pick the most advanced existing video as the burn target.
  const input = fs.existsSync(p.composited) ? p.composited
    : fs.existsSync(p.preview) ? p.preview : null;
  if (!input) { console.error('No video to caption yet — run graphics or rough cut first.'); process.exit(1); }
  fs.copyFileSync(input, path.join(p.work, 'caption-input.mp4'));

  // Bundle fonts for libass (avoids Windows path-escaping in the filtergraph).
  const fontsSrc = path.join(process.cwd(), 'assets', 'fonts');
  let fontsdir = '';
  if (fs.existsSync(fontsSrc) && fs.readdirSync(fontsSrc).some((f) => /\.(ttf|otf)$/i.test(f))) {
    const dst = path.join(p.work, 'fonts');
    ensureDir(dst);
    for (const f of fs.readdirSync(fontsSrc)) if (/\.(ttf|otf)$/i.test(f)) fs.copyFileSync(path.join(fontsSrc, f), path.join(dst, f));
    fontsdir = ':fontsdir=fonts';
  }

  const ffmpeg = resolveTool('ffmpeg', cfg);
  console.log('Burning captions...');
  const code = await stream(ffmpeg, [
    '-hide_banner', '-loglevel', 'warning', '-stats', '-y',
    '-i', 'caption-input.mp4',
    '-vf', `subtitles=captions.ass${fontsdir}`,
    '-c:v', 'libx264', '-preset', cfg.render?.x264Preset || 'medium', '-crf', String(cfg.render?.crf ?? 18),
    '-pix_fmt', 'yuv420p', '-c:a', 'copy', '-movflags', '+faststart',
    'captioned.mp4',
  ], { cwd: p.work });
  if (code !== 0) { console.error('Caption burn failed.'); process.exit(1); }
  fs.rmSync(path.join(p.work, 'caption-input.mp4'), { force: true });

  const project = loadProject(job);
  project.steps.captions = true;
  saveProject(job, project);

  console.log(`\n✓ Captions burned → projects/${job}/work/captioned.mp4`);
  console.log(`  ${words.length} words, style "${capStyle.name}", font "${capStyle.fontName}"`);
  console.log(`\nNext: music (optional) or export.\n`);
}

main().catch((e) => { console.error('\nCaptions failed:', e.message); process.exit(1); });
