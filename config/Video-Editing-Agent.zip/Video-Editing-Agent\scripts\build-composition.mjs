#!/usr/bin/env node
// Step 3 — Graphics. Plans one graphic beat per segment (or uses a plan.json you
// authored), merges the graphics into the timeline, and renders.
//
// The auto-draft is a *starting point* — the graphics-plan / second-pass skills
// exist so Claude authors richer graphics into plan.json, then re-renders.
//
// Usage:
//   node scripts/build-composition.mjs [--job name]
//        [--redraft]     regenerate the auto plan even if plan.json exists
//        [--no-render]   plan + merge only, don't render yet
import fs from 'node:fs';
import { parseArgs, bool } from '../lib/args.mjs';
import { loadConfig } from '../lib/paths.mjs';
import { loadFormat } from '../lib/presets.mjs';
import {
  resolveJob, projectPaths, loadTimeline, saveTimeline, loadPlan, savePlan, loadProject,
} from '../lib/project.mjs';
import { renderTimeline } from './render.mjs';

const STOP = new Set(('a an the and or but so if then than that this these those of to in on at for with without from into over under about as is are was were be been being it its it\'s you your we our they them he she his her i me my do does did done have has had will would can could should just really very actually basically like know going get got go went make made want need thing things stuff okay ok yeah yes no not dont don\'t im i\'m gonna wanna kind sort lot lots more most some any all one two three what when where why how who which because your you\'re there their they\'re here now today').split(/\s+/));

function keywordPhrase(text, max = 4) {
  const toks = text.split(/\s+/).map((t) => t.replace(/[^A-Za-z0-9']/g, '')).filter(Boolean);
  const sig = toks.filter((t) => t.length >= 4 && !STOP.has(t.toLowerCase()));
  const pick = (sig.length ? sig : toks).slice(0, max);
  return pick.join(' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

function draftPlan(timeline) {
  const segments = timeline.segments.map((seg) => {
    if (seg.duration < 2.5) return { id: seg.id, graphic: null };
    const title = keywordPhrase(seg.text);
    if (!title) return { id: seg.id, graphic: null };
    return { id: seg.id, graphic: { type: 'lower-third', title, motion: 'slideUp' } };
  });
  return { job: timeline.job, format: timeline.format, segments };
}

function mergePlanIntoTimeline(timeline, plan) {
  const byId = new Map(plan.segments.map((s) => [s.id, s.graphic ?? null]));
  for (const seg of timeline.segments) {
    if (byId.has(seg.id)) seg.graphic = byId.get(seg.id);
  }
  return timeline;
}

async function main() {
  const { flags } = parseArgs();
  const cfg = loadConfig();
  const job = resolveJob(flags.job);
  const p = projectPaths(job);
  const timeline = loadTimeline(job);
  if (!timeline?.segments?.length) { console.error('No timeline yet — run the rough cut first.'); process.exit(1); }

  let plan;
  if (bool(flags.redraft) || !fs.existsSync(p.plan)) {
    plan = draftPlan(timeline);
    savePlan(job, plan);
    const n = plan.segments.filter((s) => s.graphic).length;
    console.log(`✓ Drafted graphics plan: ${n} of ${timeline.segments.length} segments get a graphic → projects/${job}/plan.json`);
    console.log('  (Edit plan.json to refine, or let the graphics-plan skill author richer graphics.)');
  } else {
    plan = loadPlan(job);
    console.log(`Using existing plan.json (${plan.segments.filter((s) => s.graphic).length} graphics).`);
  }

  mergePlanIntoTimeline(timeline, plan);
  saveTimeline(job, timeline);

  if (bool(flags['no-render'])) {
    console.log('\nPlan merged into timeline. Skipping render (--no-render).');
    console.log(`Render when ready:  node scripts/render.mjs --job ${job}\n`);
    return;
  }

  console.log('\nRendering graphics pass (first run launches Chrome per graphic segment; later edits reuse the cache)...\n');
  const r = await renderTimeline(job, cfg);
  console.log(`\n✓ Graphics pass complete — ${r.rebuilt} rebuilt, ${r.cached} cached`);
  console.log(`  preview: projects/${job}/work/composited.mp4`);
  console.log(`\nRefine graphics with the second-pass skill, then captions / music / export.\n`);
}

main().catch((e) => { console.error('\nGraphics step failed:', e.message); process.exit(1); });
