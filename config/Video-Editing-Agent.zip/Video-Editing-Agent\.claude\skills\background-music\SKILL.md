---
name: background-music
description: Step 6 of the video pipeline (optional). Mix a background music track under the voice with sidechain ducking and loudness normalization. Use when the user says "add music", "add a background track", or points to a song file.
---

# Background music — ducked bed under the voice

Step 6, optional. Mixes a track under the existing voice with sidechain ducking (music dips when the speaker talks) and re-normalizes loudness.

## Do this

```bash
node scripts/music.mjs --music "<PATH_TO_TRACK>" --job <job>
```

- Mixes onto the pre-music stage (captions output if present, else graphics, else preview) → `work/music-mixed.mp4`.
- Default bed loudness is `-23 LUFS` under the voice (barely-there, like the reference). Adjust with `--level`:

```bash
node scripts/music.mjs --music "<PATH>" --job <job> --level -26   # quieter
```

## Getting the level right
- Play back `work/music-mixed.mp4`. If the music fights the voice, go quieter (`--level -26`); if it's inaudible, louder (`--level -20`).
- Re-running always starts from the clean pre-music video, so you can iterate the level freely without stacking.

Ask the user for the track path if they haven't given one. Then move to **export**.
