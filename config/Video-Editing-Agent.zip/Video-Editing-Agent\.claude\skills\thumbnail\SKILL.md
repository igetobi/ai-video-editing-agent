---
name: thumbnail
description: Generate a thumbnail image for a video — grab a frame and optionally overlay a bold title and accent bar. Use when the user asks for a thumbnail, cover image, or is exporting long-form (which sets thumb: always).
---

# Thumbnail

Grabs a frame from the finished (or latest) video and optionally overlays a bold title with an accent bar. Writes `outputs/<job>.thumb.png`.

## Do this

```bash
node scripts/thumbnail.mjs --job <job> --title "Your hook here" --time 4
```

- `--time` — seconds into the video to grab the frame (pick an expressive frame).
- `--title` — overlaid headline. Omit for a clean frame grab.
- Uses a font from `assets/fonts/` if present, else Arial Bold on Windows.

For a richer, art-directed thumbnail, build it as a HyperFrames still composition (title + extracted frame + brand assets) — but this covers the common case in one command.
