---
name: doctor
description: Check that the video editing toolchain is installed and healthy (Node, ffmpeg, WhisperX, HyperFrames), or run first-time setup to install what's missing. Use when something errors about a missing tool, on a fresh machine, or when the user says "set up", "install dependencies", or "why isn't this working".
---

# Doctor / Setup — toolchain health

## Check what's installed

```bash
node scripts/doctor.mjs
```

Reports Node, ffmpeg/ffprobe, the WhisperX venv, and the HyperFrames CLI, with ✓ / ! / ✗.

## Install what's missing (first-time setup)

```bash
node scripts/setup.mjs
```

Idempotent — skips anything already installed. It:
1. Installs **ffmpeg** (winget: `Gyan.FFmpeg` on Windows).
2. Installs **Python 3.11 + WhisperX** into `engine/whisperx/.venv` via `uv` (CPU / `int8` here — the GPU is integrated).
3. Installs **HyperFrames** (`npm install`) and scaffolds `engine/hyperframes`.
4. Re-runs the doctor.

## Common issues
- **ffmpeg "not found" right after install** — winget doesn't refresh a running shell's PATH, but the scripts auto-discover ffmpeg in the winget install location, so this usually resolves itself. If not, open a new terminal.
- **WhisperX first run is slow / downloads models** — expected, one-time (~1–3 GB).
- **HyperFrames render can't launch Chrome** — run `node_modules/.bin/hyperframes browser install` once.
- **`uv` missing** — install it from https://docs.astral.sh/uv/, then re-run setup.
