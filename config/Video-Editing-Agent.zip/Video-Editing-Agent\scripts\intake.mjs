#!/usr/bin/env node
// Step 1 — Intake. Copy a raw clip into a new project and detect its format.
//
// Usage:
//   node scripts/intake.mjs "C:/path/to/raw.mp4" [--job my-job] [--format long-form-youtube]
import fs from 'node:fs';
import path from 'node:path';
import { parseArgs } from '../lib/args.mjs';
import { loadConfig } from '../lib/paths.mjs';
import { probe } from '../lib/ffmpeg.mjs';
import { listFormats } from '../lib/presets.mjs';
import {
  slugify, projectPaths, ensureJobDirs, projectExists,
  saveProject, saveTimeline,
} from '../lib/project.mjs';

const { _, flags } = parseArgs();
const src = _[0] || flags.source;
if (!src) {
  console.error('Usage: node scripts/intake.mjs <raw-video-path> [--job name] [--format name]');
  process.exit(1);
}
const source = path.resolve(src);
if (!fs.existsSync(source)) { console.error(`File not found: ${source}`); process.exit(1); }

const cfg = loadConfig();
const info = probe(source, cfg);
if (!info.hasVideo) { console.error('That file has no video stream.'); process.exit(1); }

// Detect format from aspect ratio unless the user forced one.
const portrait = info.height >= info.width;
let format = flags.format;
if (!format) format = portrait ? 'short-explainer' : 'long-form-youtube';
if (!listFormats().includes(format)) {
  console.error(`Unknown format "${format}". Available: ${listFormats().join(', ')}`);
  process.exit(1);
}

let job = flags.job ? slugify(flags.job) : slugify(path.basename(source));
// Avoid clobbering an existing project.
if (projectExists(job) && !flags.force) {
  let n = 2;
  while (projectExists(`${job}-${n}`)) n++;
  job = `${job}-${n}`;
}

const p = ensureJobDirs(job);
const destName = path.basename(source);
const dest = path.join(p.raw, destName);
fs.copyFileSync(source, dest);

const project = {
  job,
  createdAt: new Date().toISOString(),
  source: path.join('raw', destName),
  sourceOriginal: source,
  format,
  style: null, // falls back to the format's default style
  media: { width: info.width, height: info.height, fps: info.fps, duration: info.duration, hasAudio: info.hasAudio },
  steps: { intake: true, roughCut: false, graphics: false, captions: false, music: false, export: false },
};
saveProject(job, project);

// Start with an empty timeline; rough-cut fills in the segments.
saveTimeline(job, {
  job, format, source: project.source, fps: cfg.render?.fps || 30,
  dims: null, segments: [],
});

const mins = Math.floor(info.duration / 60), secs = Math.round(info.duration % 60);
console.log(`\n✓ Intake complete`);
console.log(`  job:      ${job}`);
console.log(`  format:   ${format}${flags.format ? '' : ' (auto-detected)'}`);
console.log(`  source:   ${info.width}x${info.height} @ ${info.fps.toFixed(2)}fps, ${mins}m${secs}s`);
console.log(`  project:  projects/${job}/`);
console.log(`\nNext: rough cut →  node scripts/rough-cut.mjs --job ${job}\n`);
