---
name: second-pass
description: Step 4 of the video pipeline. Refine graphics one at a time with natural-language tweaks — move a card, recolor it, swap the type, add a logo, retime it — re-rendering only the changed segment thanks to the content-hash cache. Use when the user gives feedback on specific graphics like "move this to the bottom", "make it the Claude color", "change this to a flowchart", "add the mascot".
---

# Second pass — refine graphics, fast

Step 4. This is where a good edit becomes a great one, and it's the incremental-render win: editing one graphic changes only that segment's cache hash, so `render.mjs` re-renders **just that segment** and reuses everything else.

## The loop

1. The user points at a specific graphic ("the card in the intro is covering my face"). Find the matching segment in `projects/<job>/plan.json` by its `id` (cross-reference `timeline.json` text/time to locate it).
2. Edit that segment's `graphic` object in `plan.json`. Common tweaks:
   - **Move it:** set `"rect": [x,y,w,h]` (normalized). E.g. bottom third: `[0.06,0.62,0.88,0.3]`.
   - **Recolor:** `"color": "#D97757"` (the Claude accent).
   - **Change type:** `"type": "bullets"` (add `items`), `"stat"`, `"keyword"`, etc.
   - **Add a logo/PNG:** `"type":"image","src":"claude-mascot.png","float":true` (drop the file in `assets/` first).
   - **Retime:** `"start": 0.4, "duration": 2.5`.
   - **Motion:** `"motion":"pop"`, or `"float": true` for a gentle bob.
3. Merge + re-render (only changed segments rebuild):

```bash
node scripts/build-composition.mjs --job <job>
```

(It reads your edited `plan.json`, re-merges, and renders. Unchanged segments hit the cache and are skipped — you'll see "cached" counts.)

4. Show `work/composited.mp4` and repeat. You can batch several tweaks into one edit + render, or go one at a time — both are fast after the first pass.

## Tips
- If a change should apply to the base cut (a mis-timed word, wrong take), that's a **rough-cut** timeline edit, not a graphics edit — fix `timeline.json` and re-render.
- Keep a consistent visual rhythm; resist putting a graphic on literally every segment.
- Assets live in `assets/` (PNGs/logos) and `assets/fonts/` (fonts). Reference images by filename.
